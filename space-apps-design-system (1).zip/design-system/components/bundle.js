/* @ds-bundle: {"format":4,"namespace":"Crew","components":[{"name":"TierPill"},{"name":"AlertCard"},{"name":"ReviewBadge"},{"name":"SyntheticTag"},{"name":"ReadingTile"},{"name":"GapCountdown"}]} */
(function () {
  var React = window.React;
  var h = React.createElement;
  var WORDS = { green: 'Self-manage', amber: 'Crew medic', red: 'Urgent' };

  function cx() {
    return Array.prototype.filter.call(arguments, Boolean).join(' ');
  }

  function TierShape(props) {
    var tier = props.tier || 'green';
    var shape;
    if (tier === 'green') {
      shape = h('circle', { cx: 8, cy: 8, r: 6.5 });
    } else if (tier === 'amber') {
      shape = h('path', { d: 'M8 1.5L15 14H1z' });
    } else {
      shape = h('path', { d: 'M5.2 1h5.6L15 5.2v5.6L10.8 15H5.2L1 10.8V5.2z' });
    }
    return h('svg', { className: 'cr-shape cr-shape-' + tier, viewBox: '0 0 16 16', width: 14, height: 14, 'aria-hidden': 'true' }, shape);
  }

  function TierPill(props) {
    var tier = props.tier || 'green';
    return h('span', { className: cx('cr-pill', 'cr-pill-' + tier, props.className) },
      h(TierShape, { tier: tier }),
      h('span', null, props.children || WORDS[tier]));
  }

  function ReviewBadge(props) {
    return h('span', { className: 'cr-review' },
      h('svg', { viewBox: '0 0 16 16', width: 12, height: 12, 'aria-hidden': 'true' },
        h('path', { d: 'M3 8.5l3 3 7-7', fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round' })),
      'Reviewed by our ' + (props.role || 'clinician'));
  }

  function SyntheticTag(props) {
    return h('span', { className: cx('cr-synthetic', props.className) }, 'SYNTHETIC');
  }

  function AlertCard(props) {
    var tier = props.tier || 'amber';
    return h('section', { className: cx('cr-alert', 'cr-alert-' + tier) },
      h('div', { className: 'cr-alert-head' },
        h(TierPill, { tier: tier }),
        props.synthetic ? h(SyntheticTag) : null),
      h('h3', { className: 'cr-alert-title' }, props.title),
      props.steps && props.steps.length
        ? h('ol', { className: 'cr-steps' }, props.steps.map(function (s, i) { return h('li', { key: i }, s); }))
        : null,
      h('div', { className: 'cr-why' },
        h('span', { className: 'cr-why-label' }, 'Why this alert?'),
        h('p', null, props.why),
        h('p', { className: 'cr-source' },
          'Source: ' + props.source + (props.confidence ? ' · Confidence: ' + props.confidence : ''))),
      props.reviewedBy ? h(ReviewBadge, { role: props.reviewedBy }) : null);
  }

  function ReadingTile(props) {
    var tier = props.tier;
    return h('div', { className: 'cr-reading' },
      h('div', { className: 'cr-reading-label' }, props.label),
      h('div', { className: 'cr-reading-value' },
        h('span', { className: 'cr-num' }, props.value),
        h('span', { className: 'cr-unit' }, props.unit)),
      props.delta ? h('div', { className: 'cr-delta' }, props.delta) : null,
      tier ? h(TierPill, { tier: tier }) : null);
  }

  function GapCountdown(props) {
    var m = props.minutes || 0;
    var s = props.seconds || 0;
    var clock = String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
    return h('section', { className: 'cr-gap' },
      h('div', { className: 'cr-gap-kicker' }, 'Earth reply possible in'),
      h('div', { className: 'cr-gap-clock' }, clock),
      h('div', { className: 'cr-gap-where' }, props.location || ''),
      props.meanwhile && props.meanwhile.length
        ? h('div', { className: 'cr-gap-meanwhile' },
            h('div', { className: 'cr-why-label' }, 'Meanwhile'),
            h('ol', { className: 'cr-steps' }, props.meanwhile.map(function (s, i) { return h('li', { key: i }, s); })))
        : null);
  }

  window.Crew = window.Crew || {};
  Object.assign(window.Crew, {
    TierPill: TierPill,
    AlertCard: AlertCard,
    ReviewBadge: ReviewBadge,
    SyntheticTag: SyntheticTag,
    ReadingTile: ReadingTile,
    GapCountdown: GapCountdown
  });
})();
