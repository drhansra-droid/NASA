# SyntheticTag

The SYNTHETIC label. Required on every screen, chart, slide and video frame showing synthetic data.

- Always the single word SYNTHETIC, uppercase, in the `synthetic` violet.
- Place it top right of the chart or card it qualifies, not in a footer.
