import type * as React from 'react';
export type Tier = 'green' | 'amber' | 'red';
export interface TierPillProps { tier?: Tier; children?: React.ReactNode; className?: string }
export declare function TierPill(props: TierPillProps): React.ReactElement;
export interface AlertCardProps { tier?: Tier; title: string; steps?: string[]; why: string; source: string; confidence?: 'High' | 'Medium' | 'Low'; reviewedBy?: string; synthetic?: boolean }
export declare function AlertCard(props: AlertCardProps): React.ReactElement;
export interface ReviewBadgeProps { role: string }
export declare function ReviewBadge(props: ReviewBadgeProps): React.ReactElement;
export interface SyntheticTagProps { className?: string }
export declare function SyntheticTag(props: SyntheticTagProps): React.ReactElement;
export interface ReadingTileProps { label: string; value: string; unit: string; delta?: string; tier?: Tier }
export declare function ReadingTile(props: ReadingTileProps): React.ReactElement;
export interface GapCountdownProps { minutes: number; seconds?: number; location?: string; meanwhile?: string[] }
export declare function GapCountdown(props: GapCountdownProps): React.ReactElement;
declare global { interface Window { Crew: { TierPill: typeof TierPill; AlertCard: typeof AlertCard; ReviewBadge: typeof ReviewBadge; SyntheticTag: typeof SyntheticTag; ReadingTile: typeof ReadingTile; GapCountdown: typeof GapCountdown } } }
