# AlertCard

One alert: tier, a plain title, numbered checklist steps, then "Why this alert?" with its source and confidence, then the review badge.

- Title names the body system and the change, not a diagnosis.
- Steps are checklist style: imperative, a few words each, the same verbs every time.
- "Why this alert?" is required on every alert; source by name and ID, confidence High, Medium or Low.
- Show the review badge only on content that passed the clinical safety gate.
- Set `synthetic` whenever the data behind the alert is synthetic.
- Red tier cards take a 2px border; nothing else changes. No flashing, no sound in the demo.
