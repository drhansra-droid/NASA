# ReadingTile

One measured value with its unit, its change from the personal baseline, and optionally its tier.

- Value in `mono` so digits line up; unit always present.
- The delta compares with the astronaut's own baseline, in words ("+9 vs your baseline"), not a percentage.
- One unit system per screen.
