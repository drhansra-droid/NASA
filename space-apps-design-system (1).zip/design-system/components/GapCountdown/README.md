# GapCountdown

Time until a reply from Earth can arrive, beside what to do meanwhile.

- Countdown in `mono` `advisory` cyan: it is information, not a warning, so it never takes a tier colour.
- Always show where the crew is, since that sets the delay.
- Meanwhile steps come from the reviewed content library only.
