# ReviewBadge

"Reviewed by our [role]" on clinician-approved content only.

- The role, never a person's name. Never "validated", "approved" or "certified".
- The reviewing clinician chooses the role wording.
