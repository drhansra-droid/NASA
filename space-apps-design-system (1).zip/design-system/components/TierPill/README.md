# TierPill

The three escalation tiers as colour, shape and word together: circle Self-manage, triangle Crew medic, octagon Urgent.

- Always render the default words; pass children only to add context after the word, never to replace it.
- One pill per body system or reading. Never show a tier colour without its shape and word: in Day theme the three colours sit at similar lightness.
- Do not use tier colours for anything else, including form errors or brand moments.
