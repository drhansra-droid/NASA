# Space Apps 2026 Team

Mission Control outside, Flight Deck inside: calm, procedural and exact.

This is the shared look and voice for everything our team makes at NASA Space Apps 2026: briefings, slides, the 30-second video, the project page and the app. Point any Claude at this system before making a page, slide or screen.

## Two modes, one system

| Mode | Where | Look | Accent |
| --- | --- | --- | --- |
| **Mission Control** | Briefings, slides, video title cards, project page, team page | Deep navy, off-white panels, condensed headlines, mono labels and numbers | `signal` orange, once per view |
| **Flight Deck** | The app, especially alert and gap screens | Near-black Cabin theme, colour only for meaning, tabular numbers | `advisory` cyan for actions; tier colours for status only |

The rule that joins them: **`signal` orange never appears on an app screen that shows a tier.** Next to `tier-amber` it reads as a warning.

## Voice

One house voice for everyone, in every mode.

- Australian English, plain words, sentences under about 25 words, active voice.
- Lead with the point, then the reason, then the source.
- Mission Control text is procedural: short sentences, numbered steps, figures with units, a status line first ("Ready for kick-off. Two tasks open.").
- Flight Deck instructions are checklist style: imperative, a few words, the same verbs every time ("Check cabin CO₂. Repeat vision test.").
- Health text explains why before what, in "you" and "your", and never alarms.
- Assessment, not diagnosis: "Suggests a change in your eyes", never "You have SANS".

### Fixed words

| Use | Never |
| --- | --- |
| Self-manage | Normal, OK, safe |
| Crew medic | Doctor, CMO (in the UI) |
| Urgent | Emergency, critical, danger |
| Reviewed by our [role] | A person's name, "validated", "approved" |
| SYNTHETIC | Simulated, demo, sample, fake |

Never say "first", "validated", "clinically proven" or "NASA-integrated", or close variants, anywhere.

## Colour

- Tokens are semantic; use the names, never raw hex. Cabin (dark) is the first theme and the app default; Day (light) is for the project page and print.
- `tier-green`, `tier-amber`, `tier-red` mean Self-manage, Crew medic and Urgent, and nothing else. In Day theme the three sit at similar lightness, so a tier is **always** colour plus shape plus word: circle Self-manage, triangle Crew medic, octagon Urgent.
- Text on a tier fill uses the matching `-soft` token as background with `ink` or the tier colour as text. Never white text on a tier colour.
- `synthetic` is its own violet so the SYNTHETIC label is never read as a status.
- Depth comes from `surface-000` → `surface-100` → `surface-200`, not shadows. The only shadow is `focus-ring`.
- Every text pairing passes 4.5:1 in both themes; checked when built.

## Type

- **IBM Plex Sans Condensed** (`display`) for Mission Control headlines and kickers.
- **IBM Plex Sans** (`sans`) for all body, labels and guidance.
- **IBM Plex Mono** (`mono`) for every measured number and the countdown, so digits line up.
- All three load from Google Fonts: `https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Sans+Condensed:wght@600;700&family=IBM+Plex+Mono:wght@500&display=swap`.
- Sentence case everywhere except `kicker`, the SYNTHETIC label and checklist verbs.

## Numbers and units

- Every value carries its unit: `68 bpm`, `118/76 mmHg`, `3.4 mmHg CO₂`, `52 mSv`.
- One unit system per screen. Glucose is mmol/L unless the whole screen is in mg/dL; never both.
- A reading shows its change from the personal baseline beside it ("+9 vs your baseline").

## Data, sources and credit

- Every alert carries a one-line "Why this alert?" with its source and a confidence label (High, Medium, Low).
- Credit NASA and partner data in text by name, dataset ID and link, for example "NASA OSDR, OSD-569". No NASA or agency logos, flags or mission identifiers, ever.
- SYNTHETIC appears on every screen, chart and slide that shows synthetic data.
- AI-generated images or video carry a visible "AI-generated" watermark.

## Iconography and imagery

- Tier shapes are the only status icons: circle, triangle, octagon, drawn as simple filled SVG in the tier colour.
- Other icons: 24px, 1.75 stroke, `currentColor`, drawn by us or openly licensed and logged in `visuals/CATALOGUE.md`.
- No stock astronauts, no NASA imagery, no gradients, no emoji.

## Components

`components/bundle.js` exposes `window.Crew` (React 18): `TierPill`, `AlertCard`, `ReviewBadge`, `SyntheticTag`, `ReadingTile`, `GapCountdown`. Each has a guideline and a live preview. Flight Deck components; use them as the reference for the app build after kick-off.

## Timing

The team look (Mission Control) is preparation and fine to use now. Applying this system to the app's own screens is design work for our idea: do that after 9:00 am Saturday, with Mark.
